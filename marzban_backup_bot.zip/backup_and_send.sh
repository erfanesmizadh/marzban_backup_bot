#!/bin/bash

# بارگذاری تنظیمات
ENV_PATH="$(dirname "$0")/config.env"
if [ ! -f "$ENV_PATH" ]; then
  echo "❌ فایل config.env پیدا نشد!"
  exit 1
fi

source "$ENV_PATH"

BACKUP_DIR="/root/marzban_backups"
NOW=$(date +"%Y-%m-%d_%H-%M-%S")
BACKUP_NAME="marzban_backup_${NOW}.sql"
ZIP_NAME="${BACKUP_NAME}.zip"

mkdir -p "$BACKUP_DIR"
cd "$BACKUP_DIR" || exit

mysqldump -u "$DB_USER" -p"$DB_PASS" -h "$DB_HOST" "$DB_NAME" > "$BACKUP_NAME"
zip "$ZIP_NAME" "$BACKUP_NAME"

curl -s -X POST "https://api.telegram.org/bot${BOT_TOKEN}/sendDocument" \
  -F chat_id="$CHAT_ID" \
  -F document=@"$ZIP_NAME" \
  -F caption="📦 Marzban Backup - $NOW"

rm -f "$BACKUP_NAME" "$ZIP_NAME"
